<div class="row">
	<div class="left-nav">
		<ul class="main-nav">
			<li><a class="nav-title" href="javascript:void(0)">Sales / Invoicing</a></li>
			<li><a href="pos_dashboard.php">POS Dashboard</a></li>
			<li><a href="item_master.php">Item Master</a></li>
			<li><a href="{{route('inventory.index')}}">Inventory Master</a></li>
			<li><a href="costing_pricing.php">Costing vs Pricing</a></li>
			<li><a href="print_barcode.php">Print Barcode</a></li>
			<li><a href="{{route('requisition.index')}}">Requisition / Pre-Order</a></li>
			<li><a href="{{route('purchase.index')}}">Purchase Master</a></li>
			<li><a href="customer_master.php">Customer Master</a></li>
			<li><a href="{{route('vendor.index')}}">Vendor Master</a></li>
			<li><a href="payables.php">Payables</a></li>
			<li><a href="receivables.php">Receivables</a></li>
			<li><a href="accounts.php">Manage Accounts</a></li>
			<li><a href="spos_settings.php">Standard POS Settings</a></li>
			<!-- <li><a href="basic_pos.php">Basic Point of Sales</a></li> -->
			<li><a href="standard_pos.php">POS Window</a></li>
			<!-- <li><a href="premium_pos.php">Premium Point of Sales</a></li> -->
		</ul>
	</div>
</div>