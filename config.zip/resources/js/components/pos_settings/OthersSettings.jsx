import React, { useEffect, useState } from 'react';
import { useSelector } from 'react-redux';
import Loading from '../Loading';
import WithSingleInputComponent from '../HOC/WithSingleInputComponent';



const OthersSettings = (props) => {

    return (
        <div>asdfasdf dfsdf</div>
    );
}

export default WithSingleInputComponent(OthersSettings);
