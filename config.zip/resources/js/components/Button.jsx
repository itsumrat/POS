import React from 'react';

const Button = () => { 

        return (
            <>
                <i className="fa fa-pencil" style={{ cursor: 'pointer' }}></i>
            </>
        );
    
}

export default Button;