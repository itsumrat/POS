import React, { Component } from 'react';
import { Routes, Route } from 'react-router-dom';
import Standardpos from './StandardPos';

class RouterPos extends Component {
    render() {
        return (
            <React.Fragment>            
                <div className="col-12">
                    hello
                </div>
            </React.Fragment>
        );
    }
}

export default RouterPos;