
export const register = (access) => {

    return {
        type: "REGISTER",
        posWindowStatus: access
        
    }
}